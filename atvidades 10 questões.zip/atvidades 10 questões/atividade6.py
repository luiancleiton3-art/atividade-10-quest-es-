import pandas as pd

# 1. Carrega os dados do arquivo CSV (Criando a variável 'dados')
dados = pd.read_csv("academia.csv")

# ==========================================
# ATIVIDADE 6 — Identificando Recordes
# ==========================================
print("--- ATIVIDADE 6 ---")

# Encontra os valores extremos de idade
maior_idade = dados["Idade"].max()
menor_idade = dados["Idade"].min()

# Localiza as linhas (e os nomes) correspondentes a esses valores
aluno_mais_velho = dados[dados["Idade"] == maior_idade]["Nome"].values[0]
aluno_mais_novo = dados[dados["Idade"] == menor_idade]["Nome"].values[0]

print(f"Aluno mais velho: {aluno_mais_velho} com {maior_idade} anos.")
print(f"Aluno mais novo: {aluno_mais_novo} com {menor_idade} anos.")
print("\n" + "=" * 50 + "\n")
# ==========================================
# ATIVIDADE 6 — Identificando Recordes
# ==========================================
print("--- ATIVIDADE 6 ---")

# Encontra os valores extremos de idade
maior_idade = dados["Idade"].max()
menor_idade = dados["Idade"].min()

# Localiza as linhas (e os nomes) correspondentes a esses valores
aluno_mais_velho = dados[dados["Idade"] == maior_idade]["Nome"].values[0]
aluno_mais_novo = dados[dados["Idade"] == menor_idade]["Nome"].values[0]

print(f"Aluno mais velho: {aluno_mais_velho} com {maior_idade} anos.")
print(f"Aluno mais novo: {aluno_mais_novo} com {menor_idade} anos.")
print("\n" + "=" * 50 + "\n")