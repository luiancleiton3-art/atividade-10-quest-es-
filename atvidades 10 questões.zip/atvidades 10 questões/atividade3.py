import pandas as pd

# 1. Importa os dados da base de produtos
df_academia = pd.read_csv("academia.csv")

# --- EXECUÇÃO DA TAREFA ---

# 2. Espia apenas as 3 primeiras linhas do arquivo
print("--- As 3 Primeiras Linhas (.head(3)) ---")
print(df_academia.head(3))

# 3. Exibe apenas os nomes das colunas da base de dados
print("\n--- Nomes das Colunas (.columns) ---")
print(df_academia.columns)
