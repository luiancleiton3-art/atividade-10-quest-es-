import pandas as pd

# 1. Carrega os dados do arquivo CSV original
dados = pd.read_csv("academia.csv")

# ==========================================
# ATIVIDADE 10 — O Desafio do Gestor (Exportação)
# ==========================================
print("--- ATIVIDADE 10 ---")

# Filtra os alunos que gastaram MAIS de 400 calorias (> 400)
# Nota: Se o gestor quiser incluir quem gastou exatamente 400, use >= 400
dados.columns = dados.columns.str.strip()
alunos_elite = dados[dados["Calorias"] > 400]

# Exibe no terminal os alunos selecionados
print("Alunos selecionados para o grupo Elite (Mais de 400 kcal):")
print(alunos_elite)

# Exporta o resultado para um novo arquivo CSV
alunos_elite.to_csv("alunos_elite.csv", index=False)

print("\nSucesso! O arquivo 'alunos_elite.csv' foi gerado na pasta do projeto.")
print("\n" + "=" * 50 + "\n")
