import pandas as pd

# 1. Carrega a base de dados da academia
dados_academia = pd.read_csv("academia.csv")

# 2. Garante a limpeza dos nomes das colunas
dados_academia.columns = dados_academia.columns.str.strip()

# --- EXECUÇÃO DA TAREFA ---

# 3. Gera e exibe o resumo estatístico completo
print("--- Resumo Estatístico Automático (.describe()) ---")
print(dados_academia.describe())
