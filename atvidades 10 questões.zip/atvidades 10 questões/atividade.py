from matplotlib.pyplot import show
import pandas as pd

dados = pd.read_csv("academia.csv")

print(dados)

print(dados.head())
print(dados.tail())
print(dados.shape)

print(dados["Idade"].mean())
dados.columns = dados.columns.str.strip()
print(dados["Calorias"].mean())
print(dados["Peso"].max())
print(dados["Peso"].min())

import matplotlib.pyplot as plt
import pandas as pd

# 1. Carrega os dados (verifique se o arquivo está na mesma pasta do script)
dados = pd.read_csv("academia.csv")

# 2. Limpeza e padronização dos nomes das colunas (evita o KeyError)
dados.columns = dados.columns.str.strip()

# --- Seus prints de diagnóstico atuais ---
print(dados)
print(dados.head())
print(dados.tail())
print(dados.shape)
print("Média de Idade:", dados["Idade"].mean())
print("Média de Calorias:", dados["Calorias"].mean())
print("Peso Máximo:", dados["Peso"].max())
print("Peso Mínimo:", dados["Minimo"].min() if "Minimo" in dados.columns else dados["Peso"].min())

# --- CÓDIGO DO GRÁFICO ---

# 3. Define o tamanho da janela do gráfico (Largura x Altura)
plt.figure(figsize=(10, 5))

# 4. Cria um gráfico de linha mostrando a evolução das Calorias ao longo dos registros
plt.plot(
    dados.index,
    dados["Calorias"],
    marker="o",
    linestyle="-",
    color="blue",
    label="Gasto Calórico",
)

# 5. Personalização visual do gráfico
plt.title("Evolução do Gasto Calórico por Atividade", fontsize=14, fontweight="bold")
plt.xlabel("Número do Registro (Linha do Arquivo)", fontsize=11)
plt.ylabel("Calorias (kcal)", fontsize=11)
plt.grid(True, linestyle="--", alpha=0.6)  # Adiciona linhas de grade ao fundo
plt.legend()  # Mostra a legenda identificando a linha do gráfico

# 6. Exibe o gráfico na tela (abre uma janela interativa no PC)
plt.tight_layout()  # Ajusta as margens automaticamente
plt.show()
