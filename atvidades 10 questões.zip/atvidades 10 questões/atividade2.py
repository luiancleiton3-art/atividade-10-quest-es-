import pandas as pd

# 1. Importação dos dados externos usando o comando chave
# Como o arquivo está na mesma pasta, basta passar o nome dele
df_produtos = pd.read_csv("produtos.csv")

# 2. Limpeza preventiva nos nomes das colunas (boa prática para evitar KeyErrors)
df_produtos.columns = df_produtos.columns.str.strip()

# 3. Exibição do DataFrame lido e informações sobre a estrutura
print("--- Dados Importados da Loja de Informática ---")
print(df_produtos)

print("\n--- Estrutura dos Dados (Linhas, Colunas) ---")
print(df_produtos.shape)