import pandas as pd

# 1. Carrega os dados do arquivo CSV
dados = pd.read_csv("academia.csv")

# ==========================================
# ATIVIDADE 9 — Contagem por Categoria
# ==========================================
print("--- ATIVIDADE 9 ---")

# Conta quantos alunos existem para cada idade registrada
contagem_idades = dados["Idade"].value_counts()

# Exibe o resultado da contagem no terminal
print("Contagem de alunos por idade:")
print(contagem_idades)
print("\n" + "=" * 50 + "\n")
